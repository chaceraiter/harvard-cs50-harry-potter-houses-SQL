from sys import argv
from cs50 import SQL
import csv

debug = True

db = SQL("sqlite:///students.db")
#db.execute("SQL QUERY")

def main(CLI):
    #verify correct number of CLIs
    if (len(CLI) != 2):
        print("Error")
        return 1

    csvfilename = argv[1]

    with open(csvfilename,"r") as studentcsv:

        reader = csv.DictReader(studentcsv, delimiter=",")

        for row in reader:

            row["name"] = row["name"].split(" ")

            if len(row["name"]) == 2:
                row["name"].append(row["name"][1])
                row["name"][1] = None


            first = row['name'][0]
            middle = row['name'][1]
            last = row['name'][2]
            house = row['house']
            birth = row['birth']

            db.execute("INSERT INTO students (first, middle, last, house, birth) VALUES (?,?,?,?,?)",
                first, middle, last, house, birth)


main(argv)