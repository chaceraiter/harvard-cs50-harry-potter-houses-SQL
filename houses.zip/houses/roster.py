from sys import argv
from cs50 import SQL
import csv

#usage:
#python roster.py Housename

#output:
#STUDENTFIRST STUDENTMIDDLEoptional STUDENTLAST, born YEAR
#STUDENTFIRST STUDENTMIDDLEoptional STUDENTLAST, born YEAR

debug = False

db = SQL("sqlite:///students.db")
#db.execute("SQL QUERY")

def main(CLI):
    if (len(CLI) != 2):
        print("Error")
        return 1

    house = CLI[1]
    #print(f"{house}")

    studentrowdict = db.execute("SELECT first,middle,last,birth FROM students WHERE house=? ORDER BY last,first",
        house)
    for row in studentrowdict:
        first = row['first']
        middle = row['middle']
        last = row['last']
        birth = row['birth']
        print(f"{first}", end=' ')
        if middle != None:
            print(f"{middle}", end=' ')
        print(f"{last}, born {birth}")


main(argv)